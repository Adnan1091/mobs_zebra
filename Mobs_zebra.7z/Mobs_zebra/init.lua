local function zebra_logic(self)
	
	if self.hp <= 0 then	
		mob_core.on_die(self)
		return
	end

	local pos = mobkit.get_stand_pos(self)
	local prty = mobkit.get_queue_priority(self)
	local player = mobkit.get_nearby_player(self)

	mob_core.random_sound(self, 16/self.dtime)

	if mobkit.timer(self,1) then 

		mob_core.vitals(self)
		mob_core.growth(self)

		if self.status ~= "following" then
            if self.attention_span > 1 then
                self.attention_span = self.attention_span - 1
                mobkit.remember(self, "attention_span", self.attention_span)
            end
		else
			self.attention_span = self.attention_span + 1
			mobkit.remember(self, "attention_span", self.attention_span)
		end

		if prty < 3
        and self.breeding then
            better_fauna.hq_breed(self, 3)
		end
		
        if prty < 2
        and player then
            if self.attention_span < 5 then
                if mob_core.follow_holding(self, player) then
                    better_fauna.hq_follow_player(self, 2, player)
                    self.attention_span = self.attention_span + 1
                end
            end
        end

		if mobkit.is_queue_empty_high(self) then
			mob_core.hq_roam(self, 0)
		end
	end
end

local random = math.random

minetest.register_entity("mobs_zebra:zebra",{
	max_hp = 25,
	view_range = 10,
	armor_groups = {fleshy = 100},
	physical = true,
	collide_with_objects = true,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1.25, 0.4},
	visual_size = {x = 5, y = 5},
	scale_stage1 = 0.5,
    scale_stage2 = 0.65,
    scale_stage3 = 0.80,
	visual = "mesh",
	mesh = "amcaw_zebra.b3d",
	textures = {
		"amcaw_zebra.png"
	},
	animation = {
		stand = {range = {x = 40, y = 80}, speed = 40, frame_blend = blend, loop = true},
		walk = {range = {x = 0, y = 50}, speed = 40, frame_blend = blend, loop = true},
		run = {range = {x = 0, y = 50}, speed = 50, frame_blend = blend, loop = true},
	},
	max_speed = 4,
	stepheight = 1.1,
	jump_height = 1.1,
	buoyancy = 0.25,
	lung_capacity = 10,
    timeout = 1200,
    ignore_liquidflag = false,
    core_growth = false,
	push_on_collide = true,
	catch_with_net = false,
	
	on_step = better_fauna.on_step,
	on_activate = better_fauna.on_activate,
	get_staticdata = mobkit.statfunc,
	logic = zebra_logic,
	on_rightclick = function(self, clicker)
		if better_fauna.feed_tame(self, clicker, 1, false, true) then return end
		mob_core.protect(self, clicker, false)
		mob_core.nametag(self, clicker, true)
	end,
	on_punch = function(self, puncher, _, tool_capabilities, dir)
		mobkit.clear_queue_high(self)
		mob_core.on_punch_basic(self, puncher, tool_capabilities, dir)
		better_fauna.hq_sporadic_flee(self, 20, puncher)
	end
})

mob_core.register_spawn({
	name = "mobs_zebra",
	nodes = {"default:sand","default:dirt_with_dry_grass","default:desert_sand"},
	min_light = 0,
	max_light = 15,
	min_height = -31000,
	max_height = 31000,
	group = 3,
	optional = {
		biomes = {
			"grassland",
			"deciduous_forest"
		}
	}
}, 16, 1)